const username = document.getElementById('username');
const firstname = document.getElementById('firstname');
const lastname = document.getElementById('lastname');
const password = document.getElementById('password');
const registerbtn = document.getElementById('registerbtn');
const loginbtn = document.getElementById('loginbtn');
const database = firebase.database();
const rootRef = database.ref('/users');

registerbtn.addEventListener('click', (e) => {
    e.preventDefault();
    rootRef.child(username.value).set({
        first_name: firstname.value,
        last_name: lastname.value,
        password: password.value
    });
});


